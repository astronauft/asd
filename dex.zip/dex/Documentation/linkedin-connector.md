This document has moved to [connectors/linkedin.md](connectors/linkedin.md).
