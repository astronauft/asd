// Package server implements an OpenID Connect server with federated logins.
package server
