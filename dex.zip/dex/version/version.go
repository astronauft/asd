// Package version contains version information for this app.
package version

// Version is set by the build scripts.
var Version = "was not built properly"
