This document has moved to [connectors/gitlab.md](connectors/gitlab.md).
