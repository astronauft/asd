# Integrations
This document tracks the libraries and tools that are compatible with dex. [Join the community](https://github.com/dexidp/dex/), and help us keep the list up-to-date.

## Tools

## Projects with a dex dependency
