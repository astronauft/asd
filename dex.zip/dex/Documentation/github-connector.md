This document has moved to [connectors/github.md](connectors/github.md).
