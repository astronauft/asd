This document has moved to [connectors/microsoft.md](connectors/microsoft.md).
