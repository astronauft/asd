This document has moved to [connectors/authproxy.md](connectors/authproxy.md).
