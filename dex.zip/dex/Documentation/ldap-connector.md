This document has moved to [connectors/ldap.md](connectors/ldap.md).
