# Production users

This document tracks people and use cases for dex in production. [Join the community](https://github.com/dexidp/dex/), and help us keep the list up-to-date.