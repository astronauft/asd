This document has moved to [connectors/saml.md](connectors/saml.md).
