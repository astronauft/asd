This document has moved to [connectors/oidc.md](connectors/oidc.md).
